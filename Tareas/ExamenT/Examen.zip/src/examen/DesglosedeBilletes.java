/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package examen;

/**
 *
 * @author usuario
 */
public class DesglosedeBilletes {
////   //Realiza un sistema que realice un desglose en billetes y monedas
//    de una cantidad exacta de colones y luego imprima el resultado en letras. 
//    Hay billetes de 1000, 2000, 5000 y monedas de 500 y 100 y 50 y 25.
////Por ejemplo, si deseamos conocer el desglose de 5225
////El programa mostrara por pantalla el siguiente resultado:
////1 billete de 5000 colones.
////1 moneda de 200 colones.
////1 moneda de 25 colones.
     public int Desglose(){
         int[]biletes
         for (int i = 0; i < 10; i++) {
             
         }
             }

    
}
