/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen;

/**
 *
 * @author usuario
 */
public class TecnicasdeCriptografia {
// Una de las técnicas de criptografía consiste en sustituir
//    cada uno de los caracteres por otro situado n posiciones más a la derecha. 
//    Si n = 2, por ejemplo, sustituiremos la a por la c, la b por la e, y así sucesivamente.
//    El problema que aparece en las ultimas n letras del alfabeto tiene fácil solución:
//    en el ejemplo, la letra y se sustituirá por la a y la letra z por la b. 
//    La sustitución debe aplicarse a las letras minúsculas y mayúsculas y a los dígitos
//    (el 0 se sustituye por el 2, el 1 por el 3 y así hasta llegar al 9, que se sustituye por el 1). 
//    Diseñe un programa que lea un texto y el valor de n  y muestre su versión criptográfica.   
//    String[]letras=new String[25]

    int a = (int) 'a';
    char[] abc = new char[26];

    public TecnicasdeCriptografia() {
        for (int i = 0; i < abc.length; i++) {
            abc[i] = (char) (a + i);
        }
    }

    public String ImprimirDesorden() {
        String x = "";
        for (int i = 0; i < abc.length; i++) {
            int y = (int) (Math.random() * 26);
            x += abc[y] + ", ";
        }
        return x;
    }

    public String ImprimirOrden() {
        String x = "";
        for (int i = 0; i < abc.length; i++) {
            x += abc[i] + ", ";
        }
        return x;
    }
}
