/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen;

import java.util.Scanner;

/**
 *
 * @author usuario
 */
public class Examen {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int opcion = 0;
        Scanner teclado = new Scanner(System.in);
        do {
            System.out.println("Digite la opcion qiue decea:");
            System.out.println("1. Tecnicas de Criptografia");
            System.out.println("2. Desglose de billetes");
            System.out.println("3.Salir");
            opcion = teclado.nextInt();
            switch (opcion) {
                case 1:
                    TecnicasdeCriptografia oTecnicasdeCriptografia = new TecnicasdeCriptografia();
                    
                    System.out.println();
                    System.out.println("Desorden:\n " + aplicacion.imprimirDesorden());
                    System.out.println();
                    System.out.println("Orden:\n " + .imprimirOrden());
                    System.exit(0);
                    break;
                case 2:
                    DesglosedeBilletes oDesglosedeBilletes = new DesglosedeBilletes();
                    teclado = new Scanner(System.in);
                    System.out.println("Digite el Monto a Desglosar");
            }

        } while (opcion < 2);
    }
}
